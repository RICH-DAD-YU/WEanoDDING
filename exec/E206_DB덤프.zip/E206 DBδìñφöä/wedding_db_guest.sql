-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7e206.p.ssafy.io    Database: wedding_db
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `guest`
--

DROP TABLE IF EXISTS `guest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guest` (
  `guest_num` int NOT NULL AUTO_INCREMENT,
  `wedding_num` int NOT NULL,
  `guest_name` varchar(255) DEFAULT NULL,
  `guest_group` varchar(255) DEFAULT NULL,
  `guest_money` int DEFAULT NULL,
  `guest_message` varchar(500) DEFAULT NULL,
  `guest_select` int DEFAULT NULL,
  `guest_phone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`guest_num`,`wedding_num`),
  KEY `FK_wedding_TO_guest_1_idx` (`wedding_num`),
  CONSTRAINT `FK_wedding_TO_guest_1` FOREIGN KEY (`wedding_num`) REFERENCES `wedding` (`wedding_num`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guest`
--

LOCK TABLES `guest` WRITE;
/*!40000 ALTER TABLE `guest` DISABLE KEYS */;
INSERT INTO `guest` VALUES (9,3,'배준식','asd',0,'asd',1,'01038009506'),(14,9,'배준식','sad',0,'asd',2,'01038009506'),(15,10,'유도경','신한 은행',0,'결혼 정말 많이 축하해',1,'01063694196'),(16,10,'배준식','삼성',30000,'축하합니다 ~~~~~~ 결혼을 진심으로 축하합니다!!!!!',1,'01038009506'),(17,10,'석민형','싸피 7기 부울경 2반',1000,'축하해~~',1,'01056604417'),(18,11,'손지민','넥슨',0,'결혼 축하해~~',1,'01076388100'),(19,11,'손지민','넥슨',0,'안녕',2,'01076388100'),(20,11,'손지민','싸피',0,'축하합니다',2,'01076388100'),(21,12,'손지민','싸피',0,'츄카링',2,'01076388100'),(29,3,'배준식','싸피 7기 부울경 2반',0,'ASDFASDFASDF',2,'01038009506'),(30,13,'석민형','ㅁㄴㅇㄹ ㅁㄴㅇㄹ',0,'ㅁㄴㅇㄹ ㅁㄴㅇㄹ',1,'01056604417'),(41,17,'윤호준','구글',5000000,'?축 결 혼?',2,'01023416245'),(42,17,'문치웅','통계청',2000000,'ヾ(≧▽≦*)o 축하합니다',1,'01083456345'),(43,17,'전인택','부산교통공사',3000000,'결혼을 축하합니다!!!',2,'01093596456'),(45,17,'남시진','통계교수',1000000,'예쁜 사랑하세요??',1,'01023452457'),(46,17,'김희태','국민은행',1000000,'축하합니다!!!',2,'01068264564'),(47,17,'설위준','네이버',4000000,'결혼 축하해 !!',1,'01028524564'),(48,17,'김장현','네이버',500000,'축하 ~~??',2,'01024582583'),(49,17,'오하민','구글',50000,'행복하세요??',1,'01029567454'),(50,17,'박정현','카카오',30000,'축하합니다??',2,'01036574543'),(51,17,'정종영','KAI',100000,'(づ￣ 3￣)づ',1,'01023734583'),(55,19,'윤호준','구글',0,'?축 결 혼?',1,'01011111111'),(56,19,'문치웅','통계청',0,'ヾ(≧▽≦*)o 축하합니다',1,'01011231211'),(57,19,'전인택','부산교통공사',0,'결혼을 축하합니다!!!',1,'01012312311'),(58,19,'남시진','통계교수',0,'예쁜 사랑하세요??',1,'01012312311'),(59,19,'김희태','국민은행',0,'축하합니다!!!',1,'01012312311'),(60,19,'설위준','네이버',0,'결혼 축하해 !!',1,'01012312311'),(61,19,'김장현','네이버',0,'축하 ~~??',1,'01012312311'),(62,19,'오하민','구글',0,'행복하세요??',1,'01012312873'),(63,19,'박정현','카카오',0,'축하합니다??',1,'01012312873'),(64,19,'정종영','KAI',0,'(づ￣ 3￣)づ',1,'01012312873'),(65,19,'최년우','현대오토에버',0,'최종합격했습니다.',1,'01025478916'),(66,19,'유도경','싸피 금융',0,'축하드립니다',1,'01063694196'),(67,19,'석민형','싸피 7기 부울경 2반',0,'축하한다!~',1,'01056604417'),(68,19,'손지민','넥슨',0,'결혼 짱 축하해 ~!~!~!~!',2,'01076388100'),(69,13,'석민형','싸피 7기 부울경 2반',0,'축하해!!~',1,'01056604417'),(70,19,'석민형','ㅁㄴㅇㄹ ㅁㄴㅇㄹ ㅁㅇㄹㄴ',0,'ㅁㄴㅇㄻㄴㅇㄹ',1,'01056604417'),(71,19,'석민형','ㄹㅇ유ㅠ',0,'ㅠ ㅊㅍ ㅊㅍ ㅊ',2,'01056604417'),(87,19,'손지민','넥슨',0,'결혼 축하해~~~!',1,'01076388100'),(89,19,'최년우','현대오토에버',0,'축하해!!!',1,'01025478916'),(92,19,'최년우','현대오토에버',0,'축하행',2,'01025478916'),(93,19,'손지민','싸피',0,'안뇽',1,'01076388100'),(94,19,'배준식','삼성',0,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ',2,'01038009506'),(95,19,'유도경','하이',0,'하이',1,'01063694196'),(96,19,'석민형','에베베ㅔ 베베베',100,'웅바바바바바바바아우아ㅣㅂ어ㅣ라ㅣ무바바바바바',2,'01056604417'),(97,19,'배준식','asdfasdfasdfasdf',0,'asdf',1,'01038009506'),(98,19,'손지민','싸피',0,'안뇽',1,'01076388100'),(115,19,'손지민','asdf',0,'sdf',2,'01076388100'),(116,19,'최년우','현대오토에버',0,'축하해',1,'01025478916'),(117,19,'최년우','현대오토에버',0,'ㅇㄴㄹㄴㅇㄴㅇ',1,'01025478916'),(118,19,'유도경','싸피 금융',0,'금융 치료',1,'01063694196'),(119,19,'석민형','ㅂㅈㄷㄱ ㅁㄴㅇㄹ',0,'ㅁㄴㅇㄼㅈㄷㄱ',2,'01056604417'),(120,19,'손지민','싸피',0,'adgag',1,'01076388100'),(121,19,'배준식','싸피 7기 부울경 2반',0,'zzzzzzzzzzzzzz',2,'01038009506');
/*!40000 ALTER TABLE `guest` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  3:24:07
