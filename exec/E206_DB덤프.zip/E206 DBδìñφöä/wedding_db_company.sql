-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7e206.p.ssafy.io    Database: wedding_db
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company` (
  `company_id` varchar(255) NOT NULL,
  `company_password` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `company_telnum` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` VALUES ('admin','$2a$10$7edKmc8wmE/Xjt2AOIWNu.XZgxGxaDysKIoBXHiE1hcqykeayQMoi','웨안오딩사장','010-2062-0620'),('asdf','$2a$10$qNXNTkfWU.Id0LGQKl42rePOjL8VkFIH1k4PeoSQCY1lAn6LIXSAe','회사이름이요','전화번호요'),('chl1380','$2a$10$FlcyI4IAIiHN5P7ygP0nEucSfQo5usTllKgN4wjjAYsbXI9GEwqHW','SSAFY웨딩홀','010-2547-8916'),('company1','$2a$10$DgRctJb8RDFUD4/bRP6afuY/J2Yj7rwgxM2iHfDD7jDxZsimblpZa','준식결혼회사','05111111111'),('dondon','$2a$10$HcEH2GnbQDOn10NxerxTlOUjsUBICkkrkj/h8WriLWinidBgObf1.','asd','1'),('ehrud9323','$2a$10$yp86W8up.ZUjRF/7v/AgdepS03k.zGxbipa3Mm2Gi1MZ3LG0TUQku','도갬웨딩홀','010-6369-4196'),('jimin1','$2a$10$OXqlx5jFaXqmh/lEZOQZDuD9ajGxwx49.81mmSGUfTpa06Iru5rWa','jiminCompany','010-1111-1111'),('test1','$2a$10$Zrox3fqsCd0PUGYpPDQqg.ZICbTPFreEEnfJR/yRN7HfxQ930tHLO','testCompany','010-1234-5678'),('wns0394','$2a$10$kkN5x55aQgJY8n4kZzld0ecNk8c4XHYWe.pJLVXni0p16g0.m7s/.','준식 결혼회사','05112341239');
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  3:24:07
