-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7e206.p.ssafy.io    Database: wedding_db
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `files` (
  `fno` int NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) DEFAULT NULL,
  `file_ori_name` varchar(255) DEFAULT NULL,
  `file_url` varchar(255) DEFAULT NULL,
  `folder_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`fno`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` VALUES (1,'JWeFEN1rz90tOD1CAfZFk8AO2MUG10nS.png','로고1.png','/home/ubuntu/download/9_asdf_asdf/','9_asdf_asdf'),(2,'ggsWndPkfiPTqApGMJUyiZUOBAnjJNTa.jpg','로고2.jpg','/home/ubuntu/download/9_asdf_asdf/','9_asdf_asdf'),(3,'AN0VOvIsif0WELrVwmEEe09fvI4fe3er.png','로고3.png','/home/ubuntu/download/9_asdf_asdf/','9_asdf_asdf'),(4,'fydQ0mqcbR6gIrXqx92EeDnZgH0xpzRW.png','결혼식사진1.png','/home/ubuntu/download/10_유도경_최연우/','10_유도경_최연우'),(5,'2x97BVGQuUu0s4pzyPCtvAIUhngYrjQO.png','결혼식사진2.png','/home/ubuntu/download/10_유도경_최연우/','10_유도경_최연우'),(6,'vUvK1sHXG69VZrAZ6BRMWLFsoz9lrjal.png','facebook_cover_photo_1.png','/home/ubuntu/download/13_배준식_김삼성/','13_배준식_김삼성'),(7,'zGsSqiO1CGrvpB54htTnNDSv8YLwlrYs.png','facebook_cover_photo_2.png','/home/ubuntu/download/13_배준식_김삼성/','13_배준식_김삼성'),(8,'kjEyKKEO4YdkxBhEkzwvYqBjfAQ11Q8s.png','facebook_profile_image.png','/home/ubuntu/download/13_배준식_김삼성/','13_배준식_김삼성'),(9,'VueFQlOeqizqIqz9OraFcKKXNZtLDfM6.png','favicon.png','/home/ubuntu/download/13_배준식_김삼성/','13_배준식_김삼성'),(10,'LjRPuHpK4qY2VcgDQ4mpYin72wByxrx0.png','linkedin_banner_image_2.png','/home/ubuntu/download/13_배준식_김삼성/','13_배준식_김삼성'),(11,'qj26ViPc013GXqyrnh4KdAL0fFaW8Yec.png','linkedin_profile_image.png','/home/ubuntu/download/13_배준식_김삼성/','13_배준식_김삼성'),(12,'PhcSxmk4VFEvufa4OjeOwdeN2K62jy6g.png','logo.png','/home/ubuntu/download/13_배준식_김삼성/','13_배준식_김삼성'),(13,'eM7srFZNIBBE2WMilDrhFT69jG8LLZCA.png','logo_transparent.png','/home/ubuntu/download/13_배준식_김삼성/','13_배준식_김삼성'),(14,'WowwmraGNbUuU5epDdFU0mfwQJgZ6Svb.jpg','1_(5).jpg','/home/ubuntu/download/15_asd_asd/','15_asd_asd'),(15,'sFuDhhog38fJDVimdFrFV9Ezf8jrrvUy.jpg','KakaoTalk_20220818_093959845.jpg','/home/ubuntu/download/16_배준식_윤지영/','16_배준식_윤지영'),(16,'0PaLp2A4UAt6d3xGKEPs1Y9U88RzNqyh.jpg','KakaoTalk_20220818_094014904.jpg','/home/ubuntu/download/16_배준식_윤지영/','16_배준식_윤지영'),(17,'AhLa2H2bZYBeMortY6I0CPVWwcptvHHW.png','KakaoTalk_20220818_103204054.png','/home/ubuntu/download/17_배준식_윤지영/','17_배준식_윤지영'),(18,'kZdRwm7SQdT37tQ0aPGvEf77jDTWK5ft.png','KakaoTalk_20220818_103213401.png','/home/ubuntu/download/17_배준식_윤지영/','17_배준식_윤지영'),(19,'b6N5r5ZEMlBVuVFclzPRDPuBJZywWbKS.png','KakaoTalk_20220818_103204054.png','/home/ubuntu/download/19_asdf_asdfasdf/','19_asdf_asdfasdf'),(20,'w0XFMxPfvnRxHheQBTD18jJQPyhJlKG0.png','KakaoTalk_20220818_103213401.png','/home/ubuntu/download/19_asdf_asdfasdf/','19_asdf_asdfasdf');
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  3:24:07
